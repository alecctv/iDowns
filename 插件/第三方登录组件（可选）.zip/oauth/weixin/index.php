<?php
include_once('../../wp-config.php');
$scope = 'snsapi_login';
$appid = _DGA('oauth_weixinid');
$appsecret = _DGA('oauth_weixinkey');
if(isset($_REQUEST['code']) && isset($_REQUEST['state'])){
	$login = new WEIXIN_LOGIN();
	$login->login($appid,$appsecret,$_REQUEST['code']);
	$login->weixin_cb();
}

?>