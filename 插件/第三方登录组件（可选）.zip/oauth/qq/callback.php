<?php  
include_once('../../wp-config.php');
$appid = _DGA('oauth_qqid');
$appkey = _DGA('oauth_qqkey');
$callback = new QQ_LOGIN();
$callback->callback($appid,$appkey,get_bloginfo('url').'/oauth/qq/callback.php');
$callback->get_openid();
if(is_user_logged_in()){
	$callback->qq_bd();
}else{
	$callback->qq_cb();
}