<?php  
include_once('../../wp-config.php');
$appid = _DGA('oauth_weiboid');
$login = new WEIBO_LOGIN();
$login->login($appid,get_bloginfo('url').'/oauth/weibo/callback.php');
?>