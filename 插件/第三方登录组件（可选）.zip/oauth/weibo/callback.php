<?php  
include_once('../../wp-config.php');
$appid = _DGA('oauth_weiboid');
$appkey = _DGA('oauth_weibokey');
$callback = new WEIBO_LOGIN();
$callback->callback($appid,$appkey,get_bloginfo('url').'/oauth/weibo/callback.php');
if(is_user_logged_in()){
	$callback->sina_bd();
}else{
	$callback->sina_cb();
}