<?php 
    function showMsg($msg, $pid=0){
?>




    <html lang="zh-CN">
        <head>
            <meta charset="UTF-8" />
            <title>文件下载 - <?php echo get_the_title($pid);?> - <?php bloginfo('name');?></title>
            <link rel="stylesheet" href="<?php echo constant("erphpdown"); ?>static/erphpdown.css" type="text/css" />
            <script type="text/javascript" src="<?php echo constant("erphpdown");?>/static/jquery-1.7.min.js"></script>
        </head>
        <body class="erphpdown-body">
            <div class="container demo-1">
                <div id="large-header" class="large-header">
                    <div id="erphpdown-download" class="erphpdown-downloadlizi">
                    <h1>文件下载</h1>
                    <?php if($pid){?>
                    <div class="title"><span>资源名称</span></div>
                    <p><a href="<?php the_permalink($pid);?>" target="_blank"><?php echo get_the_title($pid);?></a></p>
                    <?php }?>
                    <!-- 以下内容不要动 -->
                    <div class="msg"><?php echo $msg;?></div>
                    <!-- 以上内容不要动 -->
                </div>
                <canvas id="demo-canvas"></canvas>

                </div>
            </div>
        	
            <script type="text/javascript" src="<?php echo constant("erphpdown");?>/static/TweenLite.min.js"></script>

        </body>
    </html>




<?php 
    exit;
}
